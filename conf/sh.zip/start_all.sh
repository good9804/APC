
cd APCAuth
sudo sh start.sh &
 
cd ..
cd APCDashBoard
sudo sh start.sh &

cd ..
cd APCProduct
sudo sh start.sh &

cd ..
cd APCOrder
sudo sh start.sh &

cd ..
cd APCKafka
sudo sh start.sh &

cd ..
